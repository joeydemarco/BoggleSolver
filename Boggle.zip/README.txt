Author: Joseph DeMarco
Date: 03/22/2020

Notes
	* My program does not take into account upper or low case when evaluating words, potentially leading to a word like "bed" to not be recognized in a dictionionary where it is stored as "Bed" or "BED", and so on. This is easily fixable, but i left it out as it would add to the runtime of the program, even when the user provides a dictionary with already low case words. If you would like me to change this, I can.
	* I have left the method I used for testing as to depict what my process is like when initially programming my code. I like to write generalized function that can work on there own in order to test them before full implementation (though I ended up redoing some code, which got rid of most of these test suites). I would, however, normally remove them along with anything else that's unnessecary after the program is complete.
	* I am also more accustomed to using namespace std when I code (along with commenting my functions differently), but having uniformity in my projects and projects I help work on is something I strive towards, so I am more than happy to adjust.
	* Thank you for your time!